---
name: code-explainer-plus
description: 对项目代码仓库进行全量深度分析，产出结构清晰的中文技术文档，包括：每个代码文件的详细说明、文件间调用关系图谱、核心功能实现链路、关键代码段注解，以及毕业答辩问题和答案。适用于代码审查、项目交接、技术文档补全、快速上手陌生项目、理解 AI 生成代码、毕业答辩准备等场景。当用户上传代码文件/zip包/提供项目路径，并提到"分析代码"、"解释项目"、"看看这个仓库"、"生成项目文档"、"帮我理解这个代码"、"梳理代码结构"、"文件之间是什么关系"、"这个功能怎么实现的"、"答辩准备"、"答辩问题"等，必须立即激活此 skill，不要跳过。即使用户描述很简短（如"帮我看看"、"解释一下"），只要附带了代码文件，也应激活。
---

# Code Explainer Plus Skill

对项目代码仓库进行**全量覆盖**的深度分析，产出可直接使用的中文技术文档，以及用于毕业答辩的问题与答案。

核心原则：**不遗漏任何一个代码文件**，每个文件都必须出现在产物中并有独立说明。

---

## Phase 0：预处理（解压 & 探测）

### 处理压缩包

```bash
# 识别上传文件类型
file /mnt/user-data/uploads/*

# 解压 zip（最常见）
unzip -q /mnt/user-data/uploads/*.zip -d /tmp/project/
# 或 tar
tar -xf /mnt/user-data/uploads/*.tar.gz -C /tmp/project/

# 查看解压后的顶层结构
ls -la /tmp/project/
```

### 读取配置文件，判断技术栈

```bash
PROJECT_ROOT=/tmp/project  # 或上传文件实际路径

# 依次尝试读取依赖声明文件
for f in package.json requirements.txt Pipfile pyproject.toml \
          pom.xml build.gradle go.mod Cargo.toml composer.json Gemfile; do
  [ -f "$PROJECT_ROOT/$f" ] && echo "=== $f ===" && cat "$PROJECT_ROOT/$f" && echo
done

# 读取 README
[ -f "$PROJECT_ROOT/README.md" ] && cat "$PROJECT_ROOT/README.md" | head -100
```

---

## Phase 1：建立全量文件清单（必须完成）

### 生成文件清单并编号

```bash
PROJECT_ROOT=/tmp/project  # 按实际路径替换

find "$PROJECT_ROOT" -type f \
  \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.tsx" \
     -o -name "*.jsx" -o -name "*.vue" -o -name "*.java" -o -name "*.kt" \
     -o -name "*.go" -o -name "*.rs" -o -name "*.cpp" -o -name "*.c" \
     -o -name "*.h" -o -name "*.cs" -o -name "*.php" -o -name "*.rb" \
     -o -name "*.swift" -o -name "*.scala" -o -name "*.dart" \
     -o -name "*.sql" -o -name "*.sh" -o -name "*.yaml" -o -name "*.yml" \
     -o -name "*.toml" -o -name "*.json" -o -name "*.env*" \
     -o -name "Dockerfile*" -o -name "*.conf" -o -name "*.xml" \) \
  | grep -vE '(node_modules|\.git|__pycache__|\.pytest_cache|dist/|build/|\.next/|vendor/|\.venv|venv/)' \
  | sort \
  | nl -ba > /tmp/file_manifest.txt

cat /tmp/file_manifest.txt
wc -l /tmp/file_manifest.txt
```

**将此清单作为分析追踪表**：每个编号文件分析完成后打 ✅，最终产物中每个文件都必须有对应条目。

---

## Phase 2：并行分析策略（多 Agent 分工）

### 文件分组原则

将清单按**模块/目录**拆分成若干批次，每批 8-15 个文件，同时启动多个子 Agent 并行分析：

```
Agent A → 入口 & 路由层（main, app, routes, index）
Agent B → 业务逻辑层（services, controllers, handlers, use_cases）
Agent C → 数据层（models, schemas, repositories, migrations, db）
Agent D → 前端组件层（components, pages, views, layouts）
Agent E → 工具 & 公共层（utils, helpers, middleware, interceptors, common）
Agent F → 配置 & 基础设施（config, settings, Dockerfile, CI/CD, scripts）
```

若项目较小（文件 ≤ 20 个），单 Agent 顺序处理即可。

### 每个子 Agent 的分析任务模板

对分配到的每个文件，执行：

```bash
# 1. 读取文件内容
cat "$FILE_PATH"

# 2. 统计行数、提取 import 语句
wc -l "$FILE_PATH"
grep -n "^import\|^from\|^require\|^use " "$FILE_PATH" | head -30

# 3. 提取所有函数/类/方法定义
grep -n "^\(def \|class \|function \|const \|export \|func \|public \|private \|async \)" "$FILE_PATH" | head -50
```

对每个文件输出结构化分析结果（格式见 Phase 3）。

---

## Phase 3：单文件分析模板

**每个文件必须按以下结构完整输出，不可省略：**

```markdown
### 📄 `相对路径/文件名.ext`

**一句话职责**：（10-20字，精确描述这个文件做什么）

**技术要点**：语言/框架特性、设计模式、重要依赖

**依赖关系**：
- ⬆️ 被以下文件调用：`fileA.py`、`fileB.py`（如无则写"无"）
- ⬇️ 依赖以下文件：`fileC.py`（仅项目内文件，第三方库另行注明）
- 📦 第三方依赖：`jwt`、`bcrypt`（重要的列出）

**核心结构**：

| 类型 | 名称 | 说明 |
|------|------|------|
| 类 | `UserService` | 用户业务逻辑聚合 |
| 函数 | `hash_password(pwd)` | 使用 bcrypt 对密码加盐哈希 |
| 变量/常量 | `JWT_SECRET` | JWT 签名密钥，从环境变量读取 |

**关键代码段**：
（选取最能说明实现逻辑的 10-30 行，标注文件内行号）

```语言
# 行 34-45：JWT token 生成逻辑
def create_token(user_id: int) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.utcnow() + timedelta(hours=24)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")
```

**实现说明**：（1-3句话解释上面代码段的工作原理，使用自然语言）
```

---

## Phase 4：合并产出文档

所有子 Agent 完成后，汇总输出以下文件：

### 文档一：`docs/01_项目总览.md`

```markdown
# 项目总览

## 基本信息
- **项目名称**：
- **技术栈**：（语言 + 框架 + 数据库 + 主要依赖）
- **代码文件总数**：X 个（已全量分析）
- **总代码行数**：约 X 行

## 架构类型
（MVC / 前后端分离 / 微服务 / 单体 / 流水线 等）

## 系统架构图（ASCII）
```
┌─────────────────────────────────────┐
│              客户端 / 前端            │
└──────────────┬──────────────────────┘
               │ HTTP / WebSocket
┌──────────────▼──────────────────────┐
│  入口层  app.py / main.go / index.js │
├──────────────────────────────────────┤
│  路由层  routes/  →  controllers/   │
├──────────────────────────────────────┤
│  业务层  services/  /  use_cases/   │
├──────────────────────────────────────┤
│  数据层  models/  →  database       │
└──────────────────────────────────────┘
```
（根据实际项目调整）

## 核心功能模块一览

| 功能模块 | 实现路径（请求链路） | 关键文件 |
|----------|-------------------|---------|
| 用户注册/登录 | POST /api/auth → AuthController → UserService → User模型 | routes/auth.py, services/user.py |
| ... | ... | ... |

## 文件关联总图

（用树形 + 箭头描述主要调用关系，入口文件为根节点）

## 数据库 / 数据结构

（列出主要模型/表，字段及含义）
```

---

### 文档二：`docs/02_代码文件详解.md`

按目录分组，收录**全部文件**的逐文件分析（Phase 3 格式）。

文件开头附上分析覆盖统计：
```markdown
# 代码文件详解

> 分析覆盖率：XX/XX 个文件（100%）
> 分析时间：YYYY-MM-DD

## 目录

- [入口 & 路由层](#入口--路由层)
- [业务逻辑层](#业务逻辑层)
- [数据层](#数据层)
- ...
```

---

### 文档三：`docs/03_调用关系图谱.md`

```markdown
# 文件调用关系图谱

## 主要请求链路

### 链路 1：用户认证
```
POST /login
  → routes/auth.py: login_route()
  → controllers/AuthController.py: login()
  → services/AuthService.py: verify_credentials()
  → models/User.py: find_by_username()
  → utils/jwt.py: create_token()
  ← 返回 JWT token
```

## 文件依赖矩阵

| 文件 | 被谁调用 | 调用谁 |
|------|---------|-------|
| app.py | —（入口） | routes/*.py, middleware/*.py |
| services/user.py | controllers/user.py | models/user.py, utils/hash.py |
| ... | ... | ... |

## 孤立文件说明
（没有被其他文件引用的文件，说明其用途：脚本/工具/测试等）
```

---

## Phase 5：完整性校验

分析结束后，对照 Phase 1 生成的文件清单做核验：

```bash
# 统计清单中的文件数
TOTAL=$(wc -l < /tmp/file_manifest.txt)

# 在生成的文档中检查每个文件名是否出现
while IFS= read -r line; do
  fname=$(echo "$line" | awk '{print $NF}' | xargs basename)
  grep -q "$fname" /tmp/output/*.md && echo "✅ $fname" || echo "❌ 未覆盖: $fname"
done < /tmp/file_manifest.txt
```

对未覆盖的文件，追加补充分析，确保覆盖率达到 **100%**。

---

## Phase 6：答辩问题生成（新增功能）

基于前面的分析，生成 `docs/04_毕业答辩问题与答案.md`。

### 问题分类策略

使用**苏格拉底式提问**、**追问式提问**、**对比式提问**等方法，从以下角度生成问题：

1. **项目背景与选题意义**（5-8题）
2. **技术选型与架构设计**（8-12题）
3. **核心功能实现**（10-15题）
4. **难点与解决方案**（5-8题）
5. **代码质量与工程实践**（5-8题）
6. **扩展与展望**（3-5题）

### 问题模板

#### 类型 A：基础概念型（适用于老师开场提问）
> **问题**：请简单介绍一下你的项目是做什么的？
> **回答思路**：从需求背景 → 核心功能 → 技术亮点，简洁明了，3-5句话

#### 类型 B：技术深究型（适用于技术老师追问）
> **问题**：你为什么选择了 [技术A] 而不是 [技术B]？它们各有什么优缺点？
> **回答思路**：对比两者特性 → 结合项目需求说明选择理由 → 坦诚技术B的适用场景

#### 类型 C：代码细节型（适用于代码审查）
> **问题**：看代码中 [某关键代码段]，能解释一下这里的设计思路吗？
> **回答思路**：先说明这段代码的功能 → 分析实现逻辑 → 为什么这样写而不是那样写

#### 类型 D：挑战型（苏格拉底式，引导深入思考）
> **问题**：如果让你重新设计这个模块，你会怎么做？有什么可以改进的地方？
> **回答思路**：肯定当前设计 → 指出可以优化的点（性能、可维护性、扩展性）→ 给出改进方案

#### 类型 E：场景假设型
> **问题**：如果用户量突然增长 10 倍，你的系统能扛住吗？需要做哪些优化？
> **回答思路**：分析当前瓶颈 → 给出水平/垂直扩展方案 → 数据库优化、缓存、负载均衡等

### 答辩文档输出模板

```markdown
# 毕业答辩问题与答案

> 生成时间：YYYY-MM-DD
> 问题总数：约 40-50 题

---

## 📚 第一部分：项目背景与选题意义

### 问题 1
**问题**：请简单介绍一下你的项目是做什么的？解决了什么问题？
**回答**：
（基于 README 和项目总览，3-5 句话）

### 问题 2
**问题**：你为什么选择做这个项目？它的应用场景是什么？
**回答**：
（从实际需求、个人兴趣、技术挑战等角度回答）

---

## 🏗️ 第二部分：技术选型与架构设计

### 问题 1
**问题**：请介绍一下你项目的技术栈，为什么选择这些技术？
**回答**：
（列出技术栈：前端 + 后端 + 数据库 + 主要依赖，并说明选择理由）

### 问题 2
**问题**：你的项目采用了什么架构模式？为什么这样设计？
**回答**：
（MVC/前后端分离/微服务等，解释优缺点和适用性）

---

## 🔧 第三部分：核心功能实现

### 问题 1
**问题**：请介绍一下 [核心功能A] 是如何实现的？
**回答**：
（从用户请求 → 路由 → 业务逻辑 → 数据层，完整链路说明，结合关键代码段）

---

## 💡 第四部分：难点与解决方案

### 问题 1
**问题**：在开发过程中，你遇到的最大技术难点是什么？如何解决的？
**回答**：
（真实描述难点，展现解决问题的思路和过程）

---

## 🔬 第五部分：代码质量与工程实践

### 问题 1
**问题**：你是如何保证代码质量的？有做单元测试吗？
**回答**：
（代码规范、Code Review、测试覆盖、CI/CD 等）

---

## 🚀 第六部分：扩展与展望

### 问题 1
**问题**：如果让你继续完善这个项目，你会添加哪些功能？
**回答**：
（结合项目实际，给出合理的扩展方向）

---

## 🎯 答辩小贴士

### 常见追问应对
- 被问住了怎么办？诚实说"这个问题我没有深入研究过，下来我会去学习"，然后尝试从相关角度分析
- 不要和老师争辩，用"您说得对，这个确实是可以优化的地方"来回应
- 多说"我们"少说"我"，体现团队协作（如果是团队项目）

### 展示技巧
- 准备 3-5 个你最熟悉的亮点功能，主动引导老师提问
- 准备好 demo，让演示代替讲解
- 控制语速，给老师思考和记录的时间
```

---

## 输出文件写入

在项目根目录下创建 `docs` 文件夹，将所有文档写入：

```bash
mkdir -p "$PROJECT_ROOT/docs"
# 将四个文档写入 docs 目录
```

---

## 执行质量标准

| 检查项 | 要求 |
|--------|------|
| 文件覆盖率 | 100%，每个代码文件都有独立条目 |
| 调用关系 | 每个文件必须标注上游调用者和下游依赖 |
| 代码段 | 每个非配置文件至少引用 1 段关键代码 |
| 语言 | 全程中文，代码保持原样 |
| 文件路径 | 所有引用使用相对于项目根目录的路径 |
| 覆盖文件类型 | 业务代码 > 配置文件 > SQL/Schema > 脚本（优先级依次降低，但都要覆盖） |
| 答辩问题 | 至少 35 题，覆盖 6 个分类，使用多种提问方法 |

---

## 特殊情况处理

**超大项目（文件 > 100 个）**：
- 优先全量覆盖业务代码（.py/.js/.ts/.java/.go 等）
- 配置/Schema/SQL 文件做分组汇总，不必逐文件展开
- 在文档开头注明分析策略

**500 行以上的大文件**：
```bash
# 读取文件头部（import、类定义）
head -80 "$FILE"
# 读取所有函数/方法签名
grep -n "^\(def \|async def \|function \|  public\|  private\|func \)" "$FILE"
# 读取文件尾部（main 入口、导出）
tail -30 "$FILE"
```
说明"因文件较长，以下分析基于结构提取"。

**无法识别的文件**：
- 看文件名 + 文件头 10 行 + 导出/定义列表
- 如仍无法判断，标注"用途待确认，内容摘要：..."

**二进制/媒体文件**：跳过，在文档中注明"非代码文件，已跳过"。
