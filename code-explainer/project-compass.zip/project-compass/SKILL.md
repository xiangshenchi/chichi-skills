---
name: project-compass
description: 对项目代码仓库进行全量深度分析，产出结构清晰的中文技术文档套件，包括：每个代码文件的详细说明、文件间调用关系图谱（Mermaid）、核心功能实现链路、关键代码段注解、快速入门手册，以及毕业答辩问题和答案。适用于代码审查、项目交接、技术文档补全、快速上手陌生项目、理解 AI 生成代码、毕业答辩准备等场景。当用户上传代码文件/zip包/提供项目路径，并提到"分析代码"、"解释项目"、"看看这个仓库"、"生成项目文档"、"帮我理解这个代码"、"梳理代码结构"、"文件之间是什么关系"、"这个功能怎么实现的"、"答辩准备"、"答辩问题"等，必须立即激活此 skill，不要跳过。即使用户描述很简短（如"帮我看看"、"解释一下"），只要附带了代码文件，也应激活。
---

# Project Compass Skill

对项目代码仓库进行**全量覆盖**的深度分析，产出可直接使用的中文技术文档套件（5个文档），以及用于毕业答辩的问题与答案。

核心原则：**不遗漏任何一个代码文件**，每个文件都必须出现在产物中并有独立说明。

---

## Phase 0：预处理（解压 & 探测）

### 处理压缩包

```bash
# 识别上传文件类型
file /mnt/user-data/uploads/*

# 解压 zip（最常见）
unzip -q /mnt/user-data/uploads/*.zip -d /tmp/project/
# 或 tar
tar -xf /mnt/user-data/uploads/*.tar.gz -C /tmp/project/

# 查看解压后的顶层结构
ls -la /tmp/project/
```

### 读取配置文件，判断技术栈

```bash
PROJECT_ROOT=/tmp/project  # 或上传文件实际路径

for f in package.json requirements.txt Pipfile pyproject.toml \
          pom.xml build.gradle go.mod Cargo.toml composer.json Gemfile; do
  [ -f "$PROJECT_ROOT/$f" ] && echo "=== $f ===" && cat "$PROJECT_ROOT/$f" && echo
done

[ -f "$PROJECT_ROOT/README.md" ] && head -100 "$PROJECT_ROOT/README.md"
```

---

## Phase 1：建立全量文件清单（必须完成）

```bash
PROJECT_ROOT=/tmp/project

find "$PROJECT_ROOT" -type f \
  \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.tsx" \
     -o -name "*.jsx" -o -name "*.vue" -o -name "*.java" -o -name "*.kt" \
     -o -name "*.go" -o -name "*.rs" -o -name "*.cpp" -o -name "*.c" \
     -o -name "*.h" -o -name "*.cs" -o -name "*.php" -o -name "*.rb" \
     -o -name "*.swift" -o -name "*.scala" -o -name "*.dart" \
     -o -name "*.sql" -o -name "*.sh" -o -name "*.yaml" -o -name "*.yml" \
     -o -name "*.toml" -o -name "*.json" -o -name "*.env*" \
     -o -name "Dockerfile*" -o -name "*.conf" -o -name "*.xml" \) \
  | grep -vE '(node_modules|\.git|__pycache__|\.pytest_cache|dist/|build/|\.next/|vendor/|\.venv|venv/)' \
  | sort \
  | nl -ba > /tmp/file_manifest.txt

cat /tmp/file_manifest.txt
wc -l /tmp/file_manifest.txt
```

**将此清单作为分析追踪表**：每个编号文件分析完成后打 ✅，最终产物中每个文件都必须有对应条目。

---

## Phase 2：并行分析策略（多 Agent 分工）

### 文件分组原则

将清单按**模块/目录**拆分成若干批次，每批 8-15 个文件，同时启动多个子 Agent 并行分析：

```
Agent A → 入口 & 路由层（main, app, routes, index）
Agent B → 业务逻辑层（services, controllers, handlers, use_cases）
Agent C → 数据层（models, schemas, repositories, migrations, db）
Agent D → 前端组件层（components, pages, views, layouts）
Agent E → 工具 & 公共层（utils, helpers, middleware, interceptors, common）
Agent F → 配置 & 基础设施（config, settings, Dockerfile, CI/CD, scripts）
```

若项目较小（文件 ≤ 20 个），单 Agent 顺序处理即可。

### 每个子 Agent 的分析任务

对分配到的每个文件，执行：

```bash
# 1. 读取文件内容
cat "$FILE_PATH"

# 2. 统计行数、提取 import 语句
wc -l "$FILE_PATH"
grep -n "^import\|^from\|^require\|^use " "$FILE_PATH" | head -30

# 3. 提取所有函数/类/方法定义
grep -n "^\(def \|class \|function \|const \|export \|func \|public \|private \|async \)" "$FILE_PATH" | head -50
```

对每个文件输出结构化分析结果（格式见 Phase 3）。

---

## Phase 3：单文件分析模板

**每个文件必须按以下结构完整输出，不可省略：**

```markdown
### 📄 `相对路径/文件名.ext`

**一句话职责**：（10-20字，精确描述这个文件做什么）

**技术要点**：语言/框架特性、设计模式、重要依赖

**依赖关系**：
- ⬆️ 被以下文件调用：`fileA.py`、`fileB.py`（如无则写"无"）
- ⬇️ 依赖以下文件：`fileC.py`（仅项目内文件，第三方库另行注明）
- 📦 第三方依赖：`jwt`、`bcrypt`（重要的列出）

**核心结构**：

| 类型 | 名称 | 说明 |
|------|------|------|
| 类 | `UserService` | 用户业务逻辑聚合 |
| 函数 | `hash_password(pwd)` | 使用 bcrypt 对密码加盐哈希 |
| 变量/常量 | `JWT_SECRET` | JWT 签名密钥，从环境变量读取 |

**关键代码段**：（选取最能说明实现逻辑的 10-30 行，标注文件内行号）

\`\`\`语言
# 行 34-45：JWT token 生成逻辑
def create_token(user_id: int) -> str:
    payload = {"sub": user_id, "exp": datetime.utcnow() + timedelta(hours=24)}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")
\`\`\`

**实现说明**：（1-3句话解释上面代码段的工作原理）
```

---

## Phase 4：合并产出文档（共5个）

所有子 Agent 完成后，主 Agent 汇总，输出以下5个文档至 `/mnt/user-data/outputs/code-analysis/`：

---

### 文档一：`01_项目总览.md`

```markdown
# 项目总览

## 基本信息
| 项 | 内容 |
|----|------|
| 项目名称 | xxx |
| 技术栈 | 语言 + 框架 + 数据库 + 主要依赖 |
| 架构模式 | MVC / 前后端分离 / 微服务 / 单体（据实填写） |
| 代码文件总数 | XX 个（已全量覆盖） |
| 总代码行数 | 约 X,XXX 行 |

## 系统架构图（Mermaid）

\`\`\`mermaid
graph TD
    Client["客户端 / 前端"] -->|HTTP/WebSocket| Entry["入口层<br/>app.py / main.go"]
    Entry --> Router["路由层<br/>routes/ → controllers/"]
    Router --> Service["业务层<br/>services/ / use_cases/"]
    Service --> Data["数据层<br/>models/ → DB / Cache"]
\`\`\`
（根据实际项目结构调整节点和连线）

## 核心功能模块一览

| 功能模块 | 实现链路 | 关键文件 |
|----------|---------|---------|
| 用户注册/登录 | POST /api/auth → AuthController → UserService → User模型 | routes/auth.py, services/user.py |
| ... | ... | ... |

## 文件关联总图

（树形 + 箭头，入口文件为根节点，按调用层级展开）

## 数据库 / 数据结构

（主要数据表/模型，列出字段与说明）
```

---

### 文档二：`02_代码文件详解.md`

按目录分组，收录**全部文件**的逐文件分析（Phase 3 格式）。

```markdown
# 代码文件详解

> 分析覆盖率：XX/XX 个文件（100%）

## 目录导航
- [入口 & 路由层](#入口--路由层)
- [业务逻辑层](#业务逻辑层)
- [数据层](#数据层)
- [前端组件层](#前端组件层)
- [工具 & 公共层](#工具--公共层)
- [配置 & 基础设施](#配置--基础设施)

---
（各子 Agent 分析结果按此结构汇入）
```

---

### 文档三：`03_调用关系图谱.md`

```markdown
# 文件调用关系图谱

## 主要业务链路（文字版）

### 链路 1：用户登录
POST /api/login
  → routes/auth.py: login_route()
  → controllers/AuthController.py: login()
  → services/AuthService.py: verify_credentials()
    → models/User.py: find_by_username()
    → utils/security.py: verify_password()
  → utils/jwt.py: create_token()
  ← 返回 {token: "...", user: {...}}

（为每个核心功能绘制一条链路）

## 模块依赖图（Mermaid）

\`\`\`mermaid
graph LR
    app["app.py"] --> auth_routes["routes/auth.py"]
    app --> user_routes["routes/user.py"]
    auth_routes --> auth_ctrl["controllers/AuthController.py"]
    auth_ctrl --> user_svc["services/UserService.py"]
    user_svc --> user_model["models/User.py"]
    user_svc --> jwt_util["utils/jwt.py"]
\`\`\`
（根据实际 import 关系生成，每个节点为一个真实文件）

## 文件依赖矩阵

| 文件 | 被谁调用 | 依赖谁 |
|------|---------|-------|
| app.py | 无（入口） | routes/*.py, middleware/*.py |
| services/user.py | controllers/user.py | models/user.py, utils/hash.py |

## 孤立文件说明
（未被其他文件 import 的文件，说明其独立用途）
```

---

### 文档四：`04_毕业答辩问题与答案.md`

基于代码分析生成，覆盖 6 大类 × 5 种题型，至少 35 题。

**6 大分类**：项目背景（5-8题）/ 技术选型（8-12题）/ 核心功能实现（10-15题）/ 难点与解决（5-8题）/ 代码质量（5-8题）/ 扩展展望（3-5题）

**5 种题型**：
- **类型 A 基础概念型**：开场"是什么/做什么"
- **类型 B 技术深究型**：追问"为什么选X不选Y"
- **类型 C 代码细节型**：指着代码问"这里什么意思"
- **类型 D 挑战型（苏格拉底式）**：层层递进"如果重做会怎样"
- **类型 E 场景假设型**：压力测试"并发量翻10倍怎么办"

每题格式：
```markdown
### 问题 N【类型X】
**问题**：……
**回答**：（基于项目实际代码的完整回答，不写通用模板）
**代码依据**：`文件名.py` 第 X-Y 行
```

文档末尾附**答辩小贴士**：
```markdown
## 🎯 答辩小贴士

### 被问住了怎么办
诚实说"这个问题我没有深入研究过，下来会去学习"，再从相关角度尝试分析。不要和老师争辩，用"您说得对，这确实是可以优化的地方"回应。

### 展示技巧
- 准备 3-5 个最熟悉的亮点功能，主动引导老师提问
- 准备好 demo，让演示代替讲解
- 控制语速，给老师思考和记录时间
```

---

### 文档五：`05_快速入门手册.md`

帮助接手者（或答辩后的维护者）快速定位和修改代码，速查手册风格。

```markdown
# 快速入门手册

## 本地启动步骤

\`\`\`bash
# 1. 安装依赖
pip install -r requirements.txt   # 或 npm install

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env，填写数据库连接串、密钥等

# 3. 初始化数据库
python manage.py migrate   # 或对应命令

# 4. 启动服务
python app.py   # 或 npm run dev
\`\`\`
（根据实际项目调整命令）

## 关键入口文件速查

| 需求 | 去哪里改 | 文件 |
|------|---------|------|
| 新增一个 API 接口 | 路由层 + 控制器层 | routes/xxx.py, controllers/xxx.py |
| 修改数据库字段 | 数据模型 + 迁移脚本 | models/xxx.py, migrations/ |
| 修改前端页面 | 对应页面组件 | pages/xxx.vue 或 pages/xxx.tsx |
| 调整鉴权逻辑 | 中间件 | middleware/auth.py |
| 修改配置参数 | 配置文件 | config/settings.py 或 .env |

## 常见问题定位

| 现象 | 可能原因 | 排查位置 |
|------|---------|---------|
| 登录失败 | JWT密钥不匹配 / 用户不存在 | utils/jwt.py, services/user.py |
| 数据库连接失败 | 环境变量未配置 | config/database.py, .env |
| 接口 404 | 路由未注册 | routes/ 目录, app.py |

## 项目扩展指引

（基于代码分析，给出新增功能的推荐落地位置）
```

---

## Phase 5：完整性校验

```bash
OUTPUT_DIR=/mnt/user-data/outputs/code-analysis

while IFS= read -r line; do
  fname=$(echo "$line" | awk '{print $NF}' | xargs basename)
  if grep -q "$fname" "$OUTPUT_DIR/02_代码文件详解.md" 2>/dev/null; then
    echo "✅ $fname"
  else
    echo "❌ 未覆盖: $fname"
  fi
done < /tmp/file_manifest.txt
```

对所有 ❌ 文件，触发补充分析并追加到文档，确保覆盖率达到 **100%**。

---

## Phase 6：答辩问题生成

见文档四说明，直接在 Phase 4 汇总时同步生成。

---

## 输出文件写入

```bash
mkdir -p /mnt/user-data/outputs/code-analysis
# 依次 create_file 写入 5 个文档到上述目录
```

---

## 执行质量标准

| 检查项 | 要求 |
|--------|------|
| 文件覆盖率 | 100%，每个代码文件都有独立条目 |
| 调用关系 | 每个文件标注上游调用者和下游依赖 |
| 代码段引用 | 非配置文件至少 1 段关键代码，标注行号 |
| Mermaid 图 | 文档一（架构图）和文档三（依赖图）必须包含 |
| 答辩问题 | 至少 35 题，覆盖 6 分类，使用 5 种题型 |
| 快速入门手册 | 必须包含启动步骤、关键入口速查、常见问题 |
| 语言 | 全程中文，代码块保持原样 |

---

## 特殊情况处理

**超大项目（文件 > 100 个）**：增加子 Agent 数量（A1/A2...），配置/SQL 文件分组汇总不逐一展开，文档开头注明分析策略。

**500 行以上大文件**：
```bash
head -80 "$FILE"          # 文件头：import、类声明
grep -n "def \|func \|function \|class \|public \|private \|async " "$FILE"
tail -30 "$FILE"          # 文件尾：导出、入口
```
注明"因文件较长，基于结构提取分析"。

**无法识别用途的文件**：看文件头 10 行 + 导出内容，仍无法判断则标注"用途待确认，内容摘要：..."。

**二进制/媒体文件**：在文档中注明"非代码文件，已跳过"。
