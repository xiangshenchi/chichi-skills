---
name: repo-narrator
description: 对项目代码仓库进行全量深度分析，产出结构清晰的中文技术文档套件，包括：每个代码文件的详细说明、文件间调用关系图谱、核心功能实现链路、关键代码段注解，以及针对不同受众角色的问答预案文档。适用于代码审查、项目交接、技术文档补全、快速上手陌生项目、理解 AI 生成代码、演讲汇报备稿等场景。当用户上传代码文件/zip包/提供项目路径，并提到"分析代码"、"解释项目"、"看看这个仓库"、"生成项目文档"、"帮我理解这个代码"、"梳理代码结构"、"文件之间是什么关系"、"这个功能怎么实现的"等，必须立即激活此 skill，不要跳过。
---

# Code Explainer Skill

对项目代码仓库进行**全量覆盖**的深度分析，产出可直接使用的中文技术文档套件。

核心原则：
1. **不遗漏任何一个代码文件**，每个文件都必须有独立分析条目
2. **多子 Agent 并行读取**，按模块分组同时执行，最大化分析效率
3. **产出覆盖多类受众**，从技术文档到问答预案一套输出

---

## Phase 0：预处理（解压 & 探测）

```bash
# 识别上传文件类型
file /mnt/user-data/uploads/*

# 解压 zip
unzip -q /mnt/user-data/uploads/*.zip -d /tmp/project/
# 或 tar.gz
tar -xf /mnt/user-data/uploads/*.tar.gz -C /tmp/project/

ls -la /tmp/project/
```

读取技术栈相关配置：

```bash
PROJECT_ROOT=/tmp/project

for f in package.json requirements.txt Pipfile pyproject.toml \
          pom.xml build.gradle go.mod Cargo.toml composer.json Gemfile; do
  [ -f "$PROJECT_ROOT/$f" ] && echo "=== $f ===" && cat "$PROJECT_ROOT/$f" && echo
done

[ -f "$PROJECT_ROOT/README.md" ] && head -100 "$PROJECT_ROOT/README.md"
```

---

## Phase 1：建立全量文件清单（必须完成，后续所有 Agent 基于此清单分工）

```bash
PROJECT_ROOT=/tmp/project

find "$PROJECT_ROOT" -type f \
  \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.tsx" \
     -o -name "*.jsx" -o -name "*.vue" -o -name "*.java" -o -name "*.kt" \
     -o -name "*.go" -o -name "*.rs" -o -name "*.cpp" -o -name "*.c" \
     -o -name "*.h" -o -name "*.cs" -o -name "*.php" -o -name "*.rb" \
     -o -name "*.swift" -o -name "*.scala" -o -name "*.dart" \
     -o -name "*.sql" -o -name "*.sh" -o -name "*.yaml" -o -name "*.yml" \
     -o -name "*.toml" -o -name "*.json" -o -name "*.env*" \
     -o -name "Dockerfile*" -o -name "*.conf" -o -name "*.xml" \) \
  | grep -vE '(node_modules|\.git|__pycache__|\.pytest_cache|dist/|build/|\.next/|vendor/|\.venv|venv/)' \
  | sort | nl -ba > /tmp/file_manifest.txt

echo "=== 文件总数 ===" && wc -l /tmp/file_manifest.txt
cat /tmp/file_manifest.txt
```

将清单按目录分组后，分配给各子 Agent。**所有文件必须被分配，不得遗漏。**

---

## Phase 2：多子 Agent 并行分析

### 分组原则

主 Agent 读取文件清单后，**立即并行启动**以下子 Agent，每个子 Agent 独立读取并分析各自负责的文件批次：

```
┌─────────────────────────────────────────────────────────────┐
│                        主 Agent                              │
│  读取清单 → 分组 → 并行派发 → 汇总结果 → 写入最终文档          │
└────┬────────┬────────┬────────┬────────┬────────┬───────────┘
     │        │        │        │        │        │
  Agent A  Agent B  Agent C  Agent D  Agent E  Agent F
  入口层   业务层   数据层   前端层   工具层   配置层
```

### 各子 Agent 分工

| Agent | 负责目录/文件模式 | 典型文件 |
|-------|----------------|---------|
| **Agent A**（入口 & 路由） | main.*, app.*, index.*, routes/, router/ | app.py, main.go, routes/api.js |
| **Agent B**（业务逻辑） | services/, controllers/, handlers/, use_cases/, api/ | UserService.java, auth_controller.py |
| **Agent C**（数据层） | models/, schemas/, repositories/, migrations/, db/ | User.py, schema.prisma, 001_init.sql |
| **Agent D**（前端 UI） | components/, pages/, views/, layouts/, screens/ | Header.vue, LoginPage.tsx |
| **Agent E**（工具 & 公共） | utils/, helpers/, middleware/, interceptors/, common/, lib/ | jwt_helper.py, request_interceptor.ts |
| **Agent F**（配置 & 基础设施） | config/, settings/, Dockerfile, .github/, scripts/, *.yaml | docker-compose.yml, settings.py |

**规则**：
- 若某目录不存在，该 Agent 接管剩余未分配文件
- 单个 Agent 负责文件数建议上限 15 个，超出则拆分成 Agent A1/A2 等
- 每个子 Agent 必须对分配到的**每一个文件**完成分析，不得跳过
- 项目文件 ≤ 20 个时，可由主 Agent 单线程顺序处理

### 子 Agent 标准分析流程

每个子 Agent 对负责的每个文件依次执行：

```bash
FILE="$FILE_PATH"

# 1. 读取完整内容（< 500行文件直接 cat）
cat "$FILE"

# 2. 大文件（≥ 500 行）分段读取
wc -l "$FILE"
head -80 "$FILE"          # 文件头：import、类声明
grep -n "def \|func \|function \|class \|public \|private \|async " "$FILE"  # 所有定义
tail -30 "$FILE"          # 文件尾：导出、入口

# 3. 提取依赖声明
grep -n "^import\|^from\|^require\|^use\|^include\|^using" "$FILE" | head -40
```

---

## Phase 3：单文件分析模板

**每个文件必须按以下结构完整输出，子 Agent 直接生成此格式：**

````markdown
### 📄 `相对路径/文件名.ext`

**一句话职责**：（精确描述这个文件在项目中做什么，15字以内）

**技术要点**：所用框架特性、设计模式、算法、重要机制

**依赖关系**：
- ⬆️ 被以下文件调用：`fileA.py`、`fileB.ts`（无则写"无，为入口/独立脚本"）
- ⬇️ 依赖以下项目文件：`fileC.py`、`fileD.py`
- 📦 关键第三方库：`bcrypt`（密码哈希）、`sqlalchemy`（ORM）

**核心结构**：

| 类型 | 名称 | 说明 |
|------|------|------|
| 类 | `UserService` | 封装所有用户相关业务逻辑 |
| 函数 | `create_token(user_id)` | 生成 HS256 签名的 JWT |
| 常量 | `JWT_EXPIRE_HOURS = 24` | token 有效期配置 |

**关键代码段**：

```语言
# 文件行 34-46：核心逻辑描述
def create_token(user_id: int) -> str:
    payload = {"sub": user_id, "exp": datetime.utcnow() + timedelta(hours=24)}
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")
```

**实现说明**：此处用 HS256 对称签名算法生成 JWT，payload 中嵌入用户 ID 和过期时间，服务端无需存储 session，任意实例均可验证 token 合法性。
````

---

## Phase 4：汇总产出文档（主 Agent 执行）

所有子 Agent 分析结果回收后，主 Agent 整合输出 **4 个文档**：

---

### 文档 01：`01_项目总览.md`

```markdown
# 项目总览

## 基本信息
| 项 | 内容 |
|----|------|
| 项目名称 | xxx |
| 技术栈 | Python + FastAPI + PostgreSQL + Redis |
| 架构模式 | 前后端分离 / MVC / 微服务（据实填写）|
| 代码文件总数 | XX 个（已全量覆盖） |
| 代码总行数 | 约 X,XXX 行 |

## 系统架构图

┌──────────────────────────────────┐
│           前端 / 客户端            │
└──────────┬───────────────────────┘
           │ HTTPS
┌──────────▼───────────────────────┐
│  入口层：app.py / main.go         │
├──────────────────────────────────┤
│  路由层：routes/ → controllers/  │
├──────────────────────────────────┤
│  业务层：services/ / use_cases/  │
├──────────────────────────────────┤
│  数据层：models/ → DB / Cache    │
└──────────────────────────────────┘
（根据实际项目调整层级与连接关系）

## 核心功能模块

| 功能 | 实现链路 | 涉及文件 |
|------|---------|---------|
| 用户注册 | POST /register → UserController → UserService → User模型 | routes/auth.py, services/user.py, models/user.py |
| ... | ... | ... |

## 数据模型概览

（主要数据表/模型，列出字段与说明）

## 文件调用关系总图

（树形结构，入口文件为根节点，按调用层级展开）
```

---

### 文档 02：`02_代码文件详解.md`

收录**全部文件**的逐文件分析，按模块分组。

```markdown
# 代码文件详解

> 分析覆盖：XX / XX 个文件（100%）

## 目录导航
- [入口 & 路由层](#入口--路由层)
- [业务逻辑层](#业务逻辑层)
- [数据层](#数据层)
- [前端组件层](#前端组件层)
- [工具 & 公共层](#工具--公共层)
- [配置 & 基础设施](#配置--基础设施)

---
（各子 Agent 分析结果按此结构汇入）
```

---

### 文档 03：`03_调用关系图谱.md`

```markdown
# 文件调用关系图谱

## 主要业务链路

### 链路 1：用户登录
POST /api/login
  → routes/auth.py: login_route()
  → controllers/AuthController.py: login()
  → services/AuthService.py: verify_credentials()
    → models/User.py: find_by_username()       # 查数据库
    → utils/security.py: verify_password()     # 密码比对
  → utils/jwt.py: create_token()
  ← 返回 {token: "...", user: {...}}

（为每个核心功能绘制一条链路）

## 文件依赖矩阵

| 文件 | 被谁调用 | 依赖谁 |
|------|---------|-------|
| app.py | 无（入口） | routes/*.py, middleware/*.py |
| services/user.py | controllers/user.py | models/user.py, utils/hash.py |

## 孤立文件说明

（未被其他文件 import 的文件，逐一说明其独立用途）
```

---

### 文档 04：`04_问答预案.md`（核心产物）

针对不同受众角色，预设问题并给出可直接作答的完整回答。**问题来源于代码分析结果，不凭空捏造。**

#### 问题生成策略

对每个核心功能模块，使用以下提问法生成问题：

**苏格拉底式提问**（追问本质、假设前提）：
- "为什么要用 X 而不是 Y？"
- "如果不做 Z，会发生什么？"
- "这个假设成立的前提是什么？"
- "你能举一个反例吗？"

**澄清性提问**（确认理解）：
- "你说的 X，具体是指...？"
- "这里的 Y 和那里的 Y 是同一个意思吗？"

**实现细节追问**（深挖代码）：
- "这个功能的具体实现步骤是什么？"
- "数据在哪个环节被处理/转换？"
- "出现异常时，代码是怎么处理的？"

**设计决策追问**（考察架构意图）：
- "为什么这样设计，而不是...？"
- "这个模块是否可以被替换？"
- "你的设计有什么权衡（trade-off）？"

**边界与风险提问**（压力测试）：
- "如果并发量很大，这里会有问题吗？"
- "这个功能的安全性是如何保证的？"
- "如果第三方服务挂了，会怎样？"

---

#### 文档 04 结构模板

```markdown
# 问答预案

> 基于代码实际分析生成，每个问题均有对应代码依据

---

## 🎓 角色 1：评审委员会 / 技术评委

特点：关注技术选型合理性、架构完整性、代码质量

### Q1：你的项目整体架构是怎样的？为什么这样设计？

**参考回答**：
项目采用[前后端分离 / MVC / 微服务]架构。前端使用 X 框架负责 UI 交互，后端使用 Y 框架处理业务逻辑，数据库使用 Z 存储持久化数据。这样设计的原因是...（结合代码实际结构说明）。

**代码依据**：`app.py` 第 1-30 行、`routes/` 目录结构

---

### Q2：（苏格拉底式）你说用了 JWT 做认证，那 JWT 和 Session 相比有什么优劣？你为什么选 JWT？

**参考回答**：
JWT 是无状态的，服务端不需要存储 session，适合分布式部署和前后端分离场景。本项目中...（结合 `utils/jwt.py` 的实现说明）。代价是 token 一旦签发无法主动失效，本项目通过[设置较短过期时间 / Redis 黑名单]来缓解这个问题。

**代码依据**：`utils/jwt.py`，token 有效期设置在第 X 行

---

### Q3：（实现追问）用户密码是如何存储的？如果数据库被拖库，用户密码会泄露吗？

**参考回答**：
密码使用 bcrypt 算法加盐哈希后存储，数据库中不保存明文。bcrypt 自带随机 salt，即使两个用户密码相同，哈希值也不同，可以防御彩虹表攻击。即便数据库被拖，攻击者也无法直接还原密码。

**代码依据**：`services/user.py` 第 X-Y 行 `hash_password()` 函数

---

## 👥 角色 2：普通观众 / 非技术人员

特点：不熟悉技术细节，关注"这个东西能干什么、有什么用"

### Q1：这个系统是做什么的？能帮我解决什么问题？

**参考回答**：
（用类比和生活语言描述项目功能，避免技术术语）
这个系统是一个...，就像...一样，你可以用它来...，解决了...的痛点。

---

### Q2：这个和市面上已有的 X 相比，有什么不同？

**参考回答**：
（结合项目特有功能说明差异化点）

---

## 🧑‍💻 角色 3：同行开发者 / 技术同学

特点：关注代码质量、可扩展性、具体实现手段

### Q1：你的数据库是怎么设计的？表之间是什么关系？

**参考回答**：
（结合 models/ 文件说明主要表结构和外键关系）

### Q2：（设计追问）这个模块耦合度高吗？如果要换数据库，改动大吗？

**参考回答**：
（结合代码中是否有 Repository 模式、ORM 抽象层来回答）

### Q3：（边界风险）接口有做限流或防刷保护吗？

**参考回答**：
（结合 middleware/ 或 utils/ 中是否有相关实现来回答，如果没有也要如实说明并给出改进思路）

---

## 🏢 角色 4：管理层 / 领导 / 产品负责人

特点：关注项目价值、进度、资源投入、风险

### Q1：这个项目开发难点在哪里？

**参考回答**：
（结合代码中最复杂的模块，用非技术语言说明技术挑战）

### Q2：如果要扩展 X 功能，需要多大改动？

**参考回答**：
（结合代码架构分析改动范围，给出评估）

### Q3：系统稳定性有保障吗？出了问题怎么排查？

**参考回答**：
（结合是否有日志、监控、错误处理机制来回答）

---

## ⚡ 角色 5：刁钻追问者（压力测试）

特点：故意找漏洞、问极端情况、追问"万一"

### Q1：（苏格拉底式）你说这个设计很好，但你能想到它最大的缺点是什么？

**参考回答**：
（如实分析代码现有的局限，展示客观认知，比粉饰太平更有说服力）

### Q2：如果有 10000 个用户同时请求，系统会崩吗？

**参考回答**：
（结合代码是否有连接池、缓存、异步处理等机制来回答）

### Q3：你的代码有没有 SQL 注入 / XSS 的安全风险？

**参考回答**：
（结合 ORM 使用情况、输入校验代码来回答，有即说明防护手段，无即诚实说明并给出修复思路）
```

---

## Phase 5：完整性校验

```bash
# 核验覆盖率
while IFS= read -r line; do
  fname=$(echo "$line" | awk '{print $NF}' | xargs basename)
  if grep -q "$fname" /mnt/user-data/outputs/code-analysis/02_代码文件详解.md 2>/dev/null; then
    echo "✅ $fname"
  else
    echo "❌ 未覆盖: $fname"
  fi
done < /tmp/file_manifest.txt
```

对所有 ❌ 文件，触发补充分析并追加到文档，确保覆盖率达到 **100%**。

---

## 输出文件写入

```bash
mkdir -p /mnt/user-data/outputs/code-analysis
# 依次 create_file 写入 4 个文档到上述目录
```

---

## 执行质量标准

| 检查项 | 要求 |
|--------|------|
| 文件覆盖率 | 100%，每个代码文件都有独立条目 |
| 调用关系 | 每个文件标注上游调用者和下游依赖 |
| 代码段引用 | 非配置文件至少 1 段关键代码，标注行号 |
| 问答预案 | 每个角色至少 3 个问题，回答中有代码依据 |
| 问题多样性 | 至少覆盖苏格拉底式、实现追问、边界风险 3 种提问法 |
| 语言 | 全程中文，代码块保持原样 |
| 角色覆盖 | 至少包含技术评委、非技术受众、同行开发者 3 类角色 |

---

## 特殊情况处理

**超大项目（文件 > 100 个）**：增加子 Agent 数量（A1/A2/B1/B2...），配置/SQL 文件分组汇总而非逐文件展开，在文档开头注明分析策略。

**500 行以上大文件**：分段读取（head 80 行 + grep 定义 + tail 30 行），注明"因文件较长，基于结构提取分析"。

**无法识别用途的文件**：看文件头 10 行 + 导出内容，仍无法判断则标注"用途待确认，内容摘要：..."。

**二进制/媒体文件**：在文档中注明"非代码文件，已跳过"。
