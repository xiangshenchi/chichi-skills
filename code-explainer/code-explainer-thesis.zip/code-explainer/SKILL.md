---
name: code-explainer
description: 深度分析项目代码并生成可读性强的中文技术文档，帮助用户快速理解项目结构、各文件的作用与实现细节，以及文件之间的调用关系。适用于：毕设/项目答辩备考、接手他人项目、AI 生成代码的理解、代码审查准备。当用户上传项目代码/代码文件/zip包，并说"帮我分析代码"、"解释一下这个项目"、"我要答辩了"、"帮我看看这个项目怎么实现的"、"给我生成项目文档"、"我不太懂这个代码"、"帮我梳理代码结构"等，必须立即激活此 skill，不要跳过。
---

# Code Explainer Skill

帮助用户快速深入理解项目代码，产出适合答辩、学习、交接的中文技术文档。

---

## 适用场景

- 毕设/课设代码答辩备考（不清楚 AI 生成代码的实现细节）
- 接手他人项目，需要快速上手
- 理解复杂模块间的调用关系
- 生成项目交接文档

---

## 执行流程

### Step 1：探索项目结构

```bash
# 列出目录树（忽略无关目录）
find . -type f \( -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.java" \
  -o -name "*.go" -o -name "*.rs" -o -name "*.cpp" -o -name "*.c" -o -name "*.vue" \
  -o -name "*.jsx" -o -name "*.tsx" -o -name "*.php" -o -name "*.rb" \) \
  | grep -v node_modules | grep -v .git | grep -v __pycache__ | grep -v dist | grep -v build \
  | sort

# 读取关键配置文件了解技术栈
cat package.json 2>/dev/null || cat requirements.txt 2>/dev/null || \
  cat pom.xml 2>/dev/null || cat go.mod 2>/dev/null || echo "未找到依赖配置"
```

**目标**：了解项目技术栈、语言框架、大致分层结构。

---

### Step 2：识别架构模式

根据文件结构判断架构类型，常见模式：

| 项目类型 | 特征文件/目录 | 典型架构 |
|----------|-------------|---------|
| Web 后端 | routes/, controllers/, models/, services/ | MVC / 分层架构 |
| 前端单页 | components/, pages/, store/, router/ | 组件树 + 状态管理 |
| 全栈项目 | frontend/ + backend/ 或 client/ + server/ | 前后端分离 |
| 机器学习 | train.py, model.py, dataset.py, utils/ | 训练/推理流水线 |
| 微服务 | 多个独立服务目录各有 main 入口 | 微服务架构 |

**判断入口文件**：`main.py`, `app.py`, `index.js`, `main.go`, `Application.java` 等。

---

### Step 3：逐文件深度阅读

按优先级读取文件：
1. **入口文件**（app 启动、路由注册）
2. **核心业务文件**（功能最多、最复杂的）
3. **数据层文件**（models, schemas, database）
4. **工具/公共模块**（utils, helpers, middleware）
5. **配置文件**（config, settings, constants）

对每个文件，提取：
- 文件职责（一句话）
- 核心类/函数列表
- 对外暴露的接口/导出
- 依赖了哪些其他文件（import/require）
- 关键代码段（最能说明实现逻辑的 10-30 行）

---

### Step 4：构建文件关联图谱

分析 import/require/from 语句，构建调用关系：

```
入口文件
├── 路由层 (routes/)
│   └── 调用 → 控制器层 (controllers/)
│           └── 调用 → 服务层 (services/)
│                   └── 调用 → 数据层 (models/)
└── 中间件 (middleware/)
    └── 调用 → 工具函数 (utils/)
```

用文字描述关键调用链：
- "用户发起请求 → routes/user.py → controllers/UserController → services/UserService → models/User"

---

### Step 5：生成文档

产出两类文档：

#### 文档一：项目总览（`项目分析报告.md`）

```markdown
# 项目总览

## 技术栈
...

## 系统架构
（架构图用文字/ASCII描述）

## 核心功能模块
| 功能 | 实现路径 | 关键文件 |
|------|---------|---------|
| 用户登录 | 前端表单 → POST /api/login → JWT 签发 | routes/auth.py, utils/jwt.py |

## 文件关联关系
（调用链图）

## 数据库设计
（如有 models 文件，列出主要表结构）
```

#### 文档二：逐文件说明（`代码文件详解.md`）

对每个代码文件，输出：

```markdown
## 📄 文件路径：`src/services/UserService.py`

**职责**：处理用户相关的核心业务逻辑，包括注册、登录验证、权限检查。

**依赖关系**：
- 被 `controllers/UserController.py` 调用
- 依赖 `models/User.py`（数据库操作）
- 依赖 `utils/jwt.py`（token 生成）

**核心函数说明**：

| 函数名 | 参数 | 返回值 | 作用 |
|--------|------|-------|------|
| `register_user` | username, password, email | User 对象 | 创建新用户，密码加密存储 |
| `login` | username, password | JWT token | 验证身份，签发令牌 |

**关键代码段**：
```python
# 密码哈希存储（第 34-42 行）
def register_user(self, username: str, password: str):
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    user = User(username=username, password=hashed)
    db.session.add(user)
    db.session.commit()
    return user
```

**答辩要点**：这里用了 bcrypt 做密码哈希，是业界标准的安全做法，比 MD5 更安全，因为加了随机 salt 防彩虹表攻击。
```

---

### Step 6：答辩专项补充（可选）

如果用户明确提到"答辩"，额外生成 `答辩备考要点.md`：

```markdown
# 答辩备考要点

## 你可能被问到的问题 & 参考回答

**Q：你的项目用了什么技术栈？为什么选这个？**
A：后端用 Flask/Django/SpringBoot（根据实际），因为...（结合项目代码给出理由）

**Q：登录功能是怎么实现的？**
A：（结合 routes/auth.py 和 services/AuthService.py 解释流程）

**Q：数据库是怎么设计的？**
A：（结合 models/ 目录说明主要表和关系）

**Q：[功能X] 是如何实现的？**
A：（根据代码流程给出答案）
```

---

## 输出质量标准

- ✅ 每个文件必须有一句话职责描述
- ✅ 关键代码段要标注行号（如有）和用途说明
- ✅ 调用关系用箭头或树形表示，而非纯文字列举
- ✅ 专业术语要附带通俗解释（面向非专业评审老师）
- ✅ 答辩要点要直接给出可以开口说的完整句子，不只是关键词
- ✅ 如果发现代码有明显问题（未关闭连接、SQL 注入风险等），单独列出但不扩展，保持文档聚焦

---

## 文件读取策略

遇到大型项目（文件 > 30 个）时：
1. 优先读业务核心文件，配置/测试文件按需读
2. 超过 500 行的文件，重点读开头（类定义、import）和关键函数，不逐行读
3. 遇到无法判断职责的文件，先看文件名 + 第一行注释 + export 内容

遇到压缩包（.zip）：
```bash
unzip -l archive.zip | head -50  # 先看目录
unzip archive.zip -d /tmp/project_code/  # 解压到临时目录
```

---

## 注意事项

- 输出语言：全程中文，代码保持原样
- 代码段引用格式：用代码块 + 文件路径注释标明来源
- 不要发散讨论架构优劣，聚焦"这个项目是怎么做的"
- 如果某个文件是第三方库而非项目代码，简单说明其作用即可，不深入分析
